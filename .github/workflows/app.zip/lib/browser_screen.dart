import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'cookie_manager_service.dart';
import 'profile_model.dart';

class BrowserScreen extends StatefulWidget {
  const BrowserScreen({super.key, required this.profile, required this.onProfileChanged});

  final BrowserProfile profile;
  final ValueChanged<BrowserProfile> onProfileChanged;

  @override
  State<BrowserScreen> createState() => _BrowserScreenState();
}

class _BrowserScreenState extends State<BrowserScreen> {
  final TextEditingController _address = TextEditingController();
  MethodChannel? _webChannel;
  String _title = '';
  int _progress = 0;
  bool _loading = true;
  bool _canGoBack = false;
  bool _canGoForward = false;
  String _currentUrl = '';
  bool _unsupportedProfileApi = false;

  @override
  void initState() {
    super.initState();
    _currentUrl = widget.profile.lastUrl.isNotEmpty
        ? widget.profile.lastUrl
        : widget.profile.settings.homeUrl;
    _address.text = _currentUrl;
    unawaited(CookieManagerService.isMultiProfileSupported().then((supported) {
      if (mounted) setState(() => _unsupportedProfileApi = !supported);
    }).catchError((_) {
      if (mounted) setState(() => _unsupportedProfileApi = true);
    }));
  }

  @override
  void dispose() {
    _address.dispose();
    _webChannel?.setMethodCallHandler(null);
    widget.profile.lastUrl = _currentUrl;
    widget.onProfileChanged(widget.profile);
    super.dispose();
  }

  void _onPlatformViewCreated(int viewId) {
    final channel = MethodChannel('isolated_browser/webview_$viewId');
    _webChannel = channel;
    channel.setMethodCallHandler((call) async {
      if (!mounted) return;
      final data = call.arguments is Map ? Map<Object?, Object?>.from(call.arguments as Map) : <Object?, Object?>{};
      setState(() {
        switch (call.method) {
          case 'pageStarted':
            _loading = true;
            _progress = 0;
            _currentUrl = data['url'] as String? ?? _currentUrl;
            _address.text = _currentUrl;
            break;
          case 'progress':
            _progress = (data['progress'] as num?)?.toInt() ?? _progress;
            _loading = _progress < 100;
            break;
          case 'pageFinished':
            _loading = false;
            _progress = 100;
            _currentUrl = data['url'] as String? ?? _currentUrl;
            _address.text = _currentUrl;
            _canGoBack = data['canGoBack'] as bool? ?? _canGoBack;
            _canGoForward = data['canGoForward'] as bool? ?? _canGoForward;
            _title = data['title'] as String? ?? _title;
            widget.profile.lastUrl = _currentUrl;
            widget.onProfileChanged(widget.profile);
            break;
          case 'navState':
            _canGoBack = data['canGoBack'] as bool? ?? _canGoBack;
            _canGoForward = data['canGoForward'] as bool? ?? _canGoForward;
            break;
        }
      });
    });
    unawaited(_syncNativeState(channel));
  }

  Future<void> _syncNativeState(MethodChannel channel) async {
    try {
      final state = await channel.invokeMapMethod<String, dynamic>('getState');
      if (!mounted || state == null) return;
      setState(() {
        _currentUrl = state['url'] as String? ?? _currentUrl;
        _address.text = _currentUrl;
        _title = state['title'] as String? ?? _title;
        _canGoBack = state['canGoBack'] as bool? ?? _canGoBack;
        _canGoForward = state['canGoForward'] as bool? ?? _canGoForward;
        _progress = (state['progress'] as num?)?.toInt() ?? _progress;
        _loading = _progress < 100;
      });
    } catch (_) {
      // The page may not be attached yet. Load callbacks will sync state later.
    }
  }

  String _normaliseUrl(String input) {
    var value = input.trim();
    if (value.isEmpty) return widget.profile.settings.homeUrl;
    if (!value.contains('://')) {
      if (value.contains(' ') || !value.contains('.')) {
        value = 'https://duckduckgo.com/?q=${Uri.encodeQueryComponent(value)}';
      } else {
        value = 'https://$value';
      }
    }
    final uri = Uri.tryParse(value);
    if (uri == null || !{'http', 'https'}.contains(uri.scheme.toLowerCase())) {
      return widget.profile.settings.homeUrl;
    }
    return uri.toString();
  }

  Future<void> _go(String value) async {
    final url = _normaliseUrl(value);
    _address.text = url;
    _currentUrl = url;
    await _webChannel?.invokeMethod<void>('loadUrl', <String, Object>{'url': url});
  }


  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_canGoBack,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop && _canGoBack) unawaited(_webChannel?.invokeMethod<void>('goBack') ?? Future<void>.value());
      },
      child: Scaffold(
        appBar: AppBar(
          titleSpacing: 8,
          title: Text(_title.isEmpty ? widget.profile.name : _title, maxLines: 1, overflow: TextOverflow.ellipsis),
          actions: <Widget>[
            IconButton(tooltip: 'Close browser', onPressed: () => Navigator.of(context).maybePop(), icon: const Icon(Icons.close)),
          ],
        ),
        body: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
              child: Row(
                children: <Widget>[
                  IconButton(
                    tooltip: 'Back',
                    onPressed: _canGoBack ? () => _webChannel?.invokeMethod<void>('goBack') : null,
                    icon: const Icon(Icons.arrow_back),
                  ),
                  IconButton(
                    tooltip: 'Forward',
                    onPressed: _canGoForward ? () => _webChannel?.invokeMethod<void>('goForward') : null,
                    icon: const Icon(Icons.arrow_forward),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _address,
                      keyboardType: TextInputType.url,
                      textInputAction: TextInputAction.go,
                      autocorrect: false,
                      enableSuggestions: false,
                      onSubmitted: _go,
                      decoration: const InputDecoration(
                        isDense: true,
                        hintText: 'Search or enter URL',
                        prefixIcon: Icon(Icons.public, size: 18),
                        border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12))),
                        contentPadding: EdgeInsets.symmetric(vertical: 10),
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Reload',
                    onPressed: () => _webChannel?.invokeMethod<void>('reload'),
                    icon: const Icon(Icons.refresh),
                  ),
                ],
              ),
            ),
            if (_loading)
              LinearProgressIndicator(value: _progress > 0 ? _progress / 100 : null, minHeight: 2)
            else
              const SizedBox(height: 2),
            Expanded(
              child: _unsupportedProfileApi
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(24),
                        child: Text(
                          'This Android System WebView does not support multi-profile browsing. Update Android System WebView/Chrome and reopen the app. The app will not silently fall back to shared profile storage.',
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                  : AndroidView(
                      viewType: 'isolated_browser/profile_webview',
                      onPlatformViewCreated: _onPlatformViewCreated,
                      creationParams: <String, Object?>{
                        'profileId': widget.profile.id,
                        'initialUrl': _currentUrl,
                        'settings': widget.profile.settings.toNativeMap(),
                      },
                      creationParamsCodec: const StandardMessageCodec(),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
