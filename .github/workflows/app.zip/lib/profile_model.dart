import 'dart:convert';

import 'fingerprint_engine.dart';

class ProfileSettings {
  bool javaScriptEnabled;
  bool loadImages;
  bool requireMediaGesture;
  bool blockTrackers;
  bool safeBrowsing;
  bool desktopSite;
  bool showScrollbars;
  bool enableZoom;
  bool clearSiteDataOnClose;
  int textZoom;
  String customCss;
  String customJavaScript;
  String homeUrl;

  ProfileSettings({
    this.javaScriptEnabled = true,
    this.loadImages = true,
    this.requireMediaGesture = true,
    this.blockTrackers = true,
    this.safeBrowsing = true,
    this.desktopSite = false,
    this.showScrollbars = true,
    this.enableZoom = true,
    this.clearSiteDataOnClose = false,
    this.textZoom = 100,
    this.customCss = '',
    this.customJavaScript = '',
    this.homeUrl = 'https://duckduckgo.com/',
  });

  factory ProfileSettings.fromJson(Map<String, dynamic>? json) {
    final data = json ?? <String, dynamic>{};
    return ProfileSettings(
      javaScriptEnabled: data['javaScriptEnabled'] as bool? ?? true,
      loadImages: data['loadImages'] as bool? ?? true,
      requireMediaGesture: data['requireMediaGesture'] as bool? ?? true,
      blockTrackers: data['blockTrackers'] as bool? ?? true,
      safeBrowsing: data['safeBrowsing'] as bool? ?? true,
      desktopSite: data['desktopSite'] as bool? ?? false,
      showScrollbars: data['showScrollbars'] as bool? ?? true,
      enableZoom: data['enableZoom'] as bool? ?? true,
      clearSiteDataOnClose: data['clearSiteDataOnClose'] as bool? ?? false,
      textZoom: ((data['textZoom'] as num?)?.toInt() ?? 100).clamp(50, 200).toInt(),
      customCss: data['customCss'] as String? ?? '',
      customJavaScript: data['customJavaScript'] as String? ?? '',
      homeUrl: data['homeUrl'] as String? ?? 'https://duckduckgo.com/',
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'javaScriptEnabled': javaScriptEnabled,
        'loadImages': loadImages,
        'requireMediaGesture': requireMediaGesture,
        'blockTrackers': blockTrackers,
        'safeBrowsing': safeBrowsing,
        'desktopSite': desktopSite,
        'showScrollbars': showScrollbars,
        'enableZoom': enableZoom,
        'clearSiteDataOnClose': clearSiteDataOnClose,
        'textZoom': textZoom,
        'customCss': customCss,
        'customJavaScript': customJavaScript,
        'homeUrl': homeUrl,
      };

  Map<String, dynamic> toNativeMap() => <String, dynamic>{
        ...toJson(),
        'pageEnhancementScript': FingerprintEngine.buildPageEnhancements(
          customCss: customCss,
          customJavaScript: customJavaScript,
        ),
      };
}

class BrowserProfile {
  final String id;
  String name;
  String lastUrl;
  ProfileSettings settings;
  final DateTime createdAt;

  BrowserProfile({
    required this.id,
    required this.name,
    this.lastUrl = '',
    ProfileSettings? settings,
    DateTime? createdAt,
  })  : settings = settings ?? ProfileSettings(),
        createdAt = createdAt ?? DateTime.now();

  factory BrowserProfile.fromJson(Map<String, dynamic> json) {
    return BrowserProfile(
      id: json['id'] as String,
      name: json['name'] as String? ?? 'Profile',
      lastUrl: json['lastUrl'] as String? ?? '',
      settings: ProfileSettings.fromJson(
        json['settings'] as Map<String, dynamic>?,
      ),
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ??
          DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'lastUrl': lastUrl,
        'settings': settings.toJson(),
        'createdAt': createdAt.toIso8601String(),
      };

  String encode() => jsonEncode(toJson());

  static BrowserProfile decode(String value) =>
      BrowserProfile.fromJson(jsonDecode(value) as Map<String, dynamic>);

  /// Safe configuration export: cookies, passwords, and site data are excluded.
  String exportConfiguration() => const JsonEncoder.withIndent('  ').convert(
        <String, dynamic>{
          'format': 'isolated-browser-profile-v1',
          'name': name,
          'settings': settings.toJson(),
        },
      );

  static BrowserProfile importConfiguration(String value) {
    final decoded = jsonDecode(value) as Map<String, dynamic>;
    if (decoded['format'] != 'isolated-browser-profile-v1') {
      throw const FormatException('Unsupported profile configuration format.');
    }
    final settings = ProfileSettings.fromJson(
      decoded['settings'] as Map<String, dynamic>?,
    );
    return BrowserProfile(
      id: 'profile_${DateTime.now().microsecondsSinceEpoch}',
      name: '${decoded['name'] ?? 'Imported profile'} (imported)',
      settings: settings,
    );
  }
}
