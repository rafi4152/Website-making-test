import 'package:flutter/material.dart';

import 'profile_model.dart';

class SettingsPanel extends StatefulWidget {
  const SettingsPanel({super.key, required this.profile});

  final BrowserProfile profile;

  @override
  State<SettingsPanel> createState() => _SettingsPanelState();
}

class _SettingsPanelState extends State<SettingsPanel> {
  late ProfileSettings settings;
  late TextEditingController _homeUrl;
  late TextEditingController _css;
  late TextEditingController _js;

  @override
  void initState() {
    super.initState();
    final s = widget.profile.settings;
    settings = ProfileSettings.fromJson(s.toJson());
    _homeUrl = TextEditingController(text: settings.homeUrl);
    _css = TextEditingController(text: settings.customCss);
    _js = TextEditingController(text: settings.customJavaScript);
  }

  @override
  void dispose() {
    _homeUrl.dispose();
    _css.dispose();
    _js.dispose();
    super.dispose();
  }


  Widget _switch({
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return SwitchListTile(
      title: Text(title),
      subtitle: Text(subtitle),
      value: value,
      onChanged: onChanged,
      dense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
    );
  }

  Widget _section(String title, List<Widget> children) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 4),
            child: Text(title, style: Theme.of(context).textTheme.titleSmall),
          ),
          ...children,
        ],
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.profile.name} settings'),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              settings
                ..homeUrl = _homeUrl.text.trim().isEmpty
                    ? 'https://duckduckgo.com/'
                    : _homeUrl.text.trim()
                ..customCss = _css.text
                ..customJavaScript = _js.text;
              widget.profile.settings = settings;
              Navigator.of(context).pop(widget.profile);
            },
            child: const Text('Save'),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: <Widget>[
          _section('Page & performance', <Widget>[
            _switch(
              title: 'JavaScript',
              subtitle: 'Some sites will not work when disabled.',
              value: settings.javaScriptEnabled,
              onChanged: (v) => setState(() => settings.javaScriptEnabled = v),
            ),
            _switch(
              title: 'Load images',
              subtitle: 'Turn off to reduce bandwidth use.',
              value: settings.loadImages,
              onChanged: (v) => setState(() => settings.loadImages = v),
            ),
            _switch(
              title: 'Require a tap to play media',
              subtitle: 'Prevents many videos from autoplaying.',
              value: settings.requireMediaGesture,
              onChanged: (v) => setState(() => settings.requireMediaGesture = v),
            ),
            _switch(
              title: 'Desktop site',
              subtitle: 'Requests the standard desktop WebView layout.',
              value: settings.desktopSite,
              onChanged: (v) => setState(() => settings.desktopSite = v),
            ),
            _switch(
              title: 'Zoom controls',
              subtitle: 'Allow pinch zoom and on-screen zoom controls.',
              value: settings.enableZoom,
              onChanged: (v) => setState(() => settings.enableZoom = v),
            ),
            _switch(
              title: 'Show scrollbars',
              subtitle: 'Display native WebView scroll indicators.',
              value: settings.showScrollbars,
              onChanged: (v) => setState(() => settings.showScrollbars = v),
            ),
            ListTile(
              title: const Text('Text zoom'),
              subtitle: Text('${settings.textZoom}%'),
              trailing: SizedBox(
                width: 180,
                child: Slider(
                  min: 50,
                  max: 200,
                  divisions: 15,
                  value: settings.textZoom.toDouble(),
                  label: '${settings.textZoom}%',
                  onChanged: (v) => setState(() => settings.textZoom = v.round()),
                ),
              ),
            ),
          ]),
          _section('Privacy & site data', <Widget>[
            _switch(
              title: 'Block common trackers',
              subtitle: 'Uses a small local hostname denylist; not a full ad blocker.',
              value: settings.blockTrackers,
              onChanged: (v) => setState(() => settings.blockTrackers = v),
            ),
            _switch(
              title: 'Safe Browsing',
              subtitle: 'Uses Android WebView Safe Browsing when available.',
              value: settings.safeBrowsing,
              onChanged: (v) => setState(() => settings.safeBrowsing = v),
            ),
            _switch(
              title: 'Clear site data when browser closes',
              subtitle: 'Clears cookies and origin storage for this profile.',
              value: settings.clearSiteDataOnClose,
              onChanged: (v) => setState(() => settings.clearSiteDataOnClose = v),
            ),
          ]),
          _section('Startup & page customisation', <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
              child: TextField(
                controller: _homeUrl,
                keyboardType: TextInputType.url,
                decoration: const InputDecoration(
                  labelText: 'Home URL',
                  hintText: 'https://example.com',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
              child: TextField(
                controller: _css,
                minLines: 3,
                maxLines: 6,
                decoration: const InputDecoration(
                  labelText: 'Custom CSS',
                  helperText: 'Injected after a page finishes loading.',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
              child: TextField(
                controller: _js,
                minLines: 3,
                maxLines: 8,
                decoration: const InputDecoration(
                  labelText: 'Custom JavaScript',
                  helperText: 'Runs in the page after load. Only use scripts you trust.',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: Text(
                'Custom scripts are ordinary page customisation. Browser identity spoofing, certificate-error bypasses, and proxy/DNS anonymity claims are not implemented.',
              ),
            ),
          ]),
        ],
      ),
    );
  }
}
