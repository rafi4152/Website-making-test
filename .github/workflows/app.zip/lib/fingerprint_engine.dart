import 'dart:convert';

/// Provides user-authored page customizations (CSS and JavaScript only).
///
/// This intentionally does not spoof browser APIs, alter fingerprintable
/// properties, or mask injected functions. Those techniques are unreliable and
/// can be used to bypass site anti-abuse systems.
class FingerprintEngine {
  const FingerprintEngine._();

  static String buildPageEnhancements({
    required String customCss,
    required String customJavaScript,
  }) {
    final css = jsonEncode(customCss);
    final js = customJavaScript;
    return '''
(function () {
  try {
    var cssText = $css;
    if (cssText && cssText.length) {
      var style = document.getElementById('__isolated_browser_custom_css__');
      if (!style) {
        style = document.createElement('style');
        style.id = '__isolated_browser_custom_css__';
        (document.head || document.documentElement).appendChild(style);
      }
      style.textContent = cssText;
    }
  } catch (_) {}
  try {
    // User-authored JavaScript. Keep it separate from browser identity APIs.
    $js
  } catch (_) {}
})();
''';
  }
}
