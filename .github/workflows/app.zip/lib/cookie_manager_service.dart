import 'package:flutter/services.dart';

/// Profile-scoped site-data operations delegated to AndroidX WebKit.
/// Portable cookie/session export is deliberately omitted: cookie files can
/// contain live authentication credentials.
class CookieManagerService {
  static const MethodChannel _channel = MethodChannel('isolated_browser/app');

  static Future<bool> isMultiProfileSupported() async {
    return await _channel.invokeMethod<bool>('isMultiProfileSupported') ?? false;
  }

  static Future<bool> clearProfileSiteData(String profileId) async {
    return await _channel.invokeMethod<bool>(
          'clearProfileSiteData',
          <String, Object>{'profileId': profileId},
        ) ??
        false;
  }

  static Future<bool> deleteNativeProfile(String profileId) async {
    return await _channel.invokeMethod<bool>(
          'deleteProfile',
          <String, Object>{'profileId': profileId},
        ) ??
        false;
  }
}
