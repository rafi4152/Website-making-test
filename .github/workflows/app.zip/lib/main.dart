import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show Clipboard, ClipboardData, PlatformException;
import 'package:hive_flutter/hive_flutter.dart';

import 'browser_screen.dart';
import 'cookie_manager_service.dart';
import 'profile_model.dart';
import 'settings_panel.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await Hive.openBox<String>('browserProfiles');
  runApp(const IsolatedBrowserApp());
}

class NoTransitionsBuilder extends PageTransitionsBuilder {
  const NoTransitionsBuilder();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) => child;
}

class IsolatedBrowserApp extends StatelessWidget {
  const IsolatedBrowserApp({super.key});

  @override
  Widget build(BuildContext context) {
    const noTransitions = NoTransitionsBuilder();
    return MaterialApp(
      title: 'Isolated Browser',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF326D82),
        visualDensity: VisualDensity.compact,
        pageTransitionsTheme: const PageTransitionsTheme(builders: <TargetPlatform, PageTransitionsBuilder>{
          TargetPlatform.android: noTransitions,
          TargetPlatform.iOS: noTransitions,
          TargetPlatform.linux: noTransitions,
          TargetPlatform.macOS: noTransitions,
          TargetPlatform.windows: noTransitions,
        }),
      ),
      home: const ProfilesHomeScreen(),
    );
  }
}

class ProfilesHomeScreen extends StatefulWidget {
  const ProfilesHomeScreen({super.key});

  @override
  State<ProfilesHomeScreen> createState() => _ProfilesHomeScreenState();
}

class _ProfilesHomeScreenState extends State<ProfilesHomeScreen> {
  final Box<String> _box = Hive.box<String>('browserProfiles');
  bool _profileApiSupported = true;
  bool _checkingSupport = true;

  List<BrowserProfile> get _profiles {
    final result = <BrowserProfile>[];
    for (final value in _box.values) {
      try {
        result.add(BrowserProfile.decode(value));
      } catch (_) {
        // A damaged preference entry is skipped rather than crashing startup.
      }
    }
    result.sort((a, b) => a.createdAt.compareTo(b.createdAt));
    return result;
  }

  @override
  void initState() {
    super.initState();
    unawaited(_ensureInitialProfile());
    unawaited(_checkSupport());
  }

  Future<void> _ensureInitialProfile() async {
    if (_box.isNotEmpty) return;
    final profile = BrowserProfile(
      id: 'p_${DateTime.now().microsecondsSinceEpoch}',
      name: 'Personal',
    );
    await _box.put(profile.id, profile.encode());
    if (mounted) setState(() {});
  }

  Future<void> _checkSupport() async {
    try {
      final supported = await CookieManagerService.isMultiProfileSupported();
      if (mounted) {
        setState(() {
          _profileApiSupported = supported;
          _checkingSupport = false;
        });
      }
    } on PlatformException {
      if (mounted) setState(() { _profileApiSupported = false; _checkingSupport = false; });
    }
  }

  Future<void> _save(BrowserProfile profile) async {
    await _box.put(profile.id, profile.encode());
    if (mounted) setState(() {});
  }

  Future<void> _createProfile() async {
    final nameController = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('New profile'),
        content: TextField(
          controller: nameController,
          autofocus: true,
          maxLength: 40,
          decoration: const InputDecoration(labelText: 'Profile name'),
          onSubmitted: (value) => Navigator.pop(context, value.trim()),
        ),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, nameController.text.trim()), child: const Text('Create')),
        ],
      ),
    );
    nameController.dispose();
    if (name == null || name.trim().isEmpty) return;
    final profile = BrowserProfile(
      id: 'p_${DateTime.now().microsecondsSinceEpoch}',
      name: name.trim(),
    );
    await _save(profile);
  }

  Future<void> _open(BrowserProfile profile) async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => BrowserScreen(profile: profile, onProfileChanged: _save),
      ),
    );
    if (mounted) setState(() {});
  }

  Future<void> _editSettings(BrowserProfile profile) async {
    final updated = await Navigator.of(context).push<BrowserProfile>(
      MaterialPageRoute<BrowserProfile>(builder: (_) => SettingsPanel(profile: profile)),
    );
    if (updated != null) await _save(updated);
  }

  Future<void> _clearData(BrowserProfile profile) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear site data?'),
        content: Text('This clears cookies and website storage for “${profile.name}”. You may be signed out of sites in this profile.'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Clear data')),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      final cleared = await CookieManagerService.clearProfileSiteData(profile.id);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(cleared ? 'Site data cleared.' : 'The profile data could not be cleared.'),
      ));
    } on PlatformException catch (e) {
      if (mounted) _showMessage(e.message ?? 'Could not clear profile data.');
    }
  }

  Future<void> _deleteProfile(BrowserProfile profile) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete profile?'),
        content: Text('Delete “${profile.name}” and ask Android WebView to remove its browsing data? This cannot be undone.'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      final nativeDeleted = await CookieManagerService.deleteNativeProfile(profile.id);
      if (!nativeDeleted) {
        if (mounted) _showMessage('Android WebView keeps profile handles in memory for this app session. Restart the app, then delete this profile before opening it.');
        return;
      }
      await _box.delete(profile.id);
      if (mounted) setState(() {});
    } on PlatformException catch (e) {
      if (mounted) _showMessage(e.message ?? 'Native profile deletion failed.');
    }
  }

  Future<void> _exportConfiguration(BrowserProfile profile) async {
    await Clipboard.setData(ClipboardData(text: profile.exportConfiguration()));
    if (mounted) _showMessage('Profile configuration copied. Cookies and site data are not included.');
  }

  Future<void> _importConfiguration() async {
    final controller = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Import profile configuration'),
        content: SizedBox(
          width: 440,
          child: TextField(
            controller: controller,
            minLines: 5,
            maxLines: 10,
            decoration: const InputDecoration(
              hintText: 'Paste exported profile JSON here',
              border: OutlineInputBorder(),
            ),
          ),
        ),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('Import')),
        ],
      ),
    );
    controller.dispose();
    if (value == null || value.trim().isEmpty) return;
    try {
      final profile = BrowserProfile.importConfiguration(value);
      await _save(profile);
      if (mounted) _showMessage('Configuration imported as a new profile.');
    } on FormatException catch (e) {
      if (mounted) _showMessage(e.message);
    } catch (_) {
      if (mounted) _showMessage('That JSON is not a valid Isolated Browser profile configuration.');
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final profiles = _profiles;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Isolated Browser'),
        actions: <Widget>[
          IconButton(tooltip: 'Import profile JSON', onPressed: _importConfiguration, icon: const Icon(Icons.file_download_outlined)),
          IconButton(tooltip: 'New profile', onPressed: _createProfile, icon: const Icon(Icons.add)),
        ],
      ),
      body: Column(
        children: <Widget>[
          if (!_checkingSupport && !_profileApiSupported)
            const MaterialBanner(
              content: Text('Per-profile WebView storage is not supported by this device. Update Android System WebView/Chrome. Browsing is disabled rather than falling back to shared storage.'),
              leading: Icon(Icons.warning_amber_rounded),
              actions: <Widget>[SizedBox.shrink()],
            ),
          Expanded(
            child: profiles.isEmpty
                ? const Center(child: Text('Create a profile to start browsing.'))
                : ListView.separated(
                    itemCount: profiles.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, index) {
                      final profile = profiles[index];
                      return ListTile(
                        leading: const CircleAvatar(child: Icon(Icons.person_outline)),
                        title: Text(profile.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text(profile.lastUrl.isEmpty ? 'Separate website storage' : profile.lastUrl, maxLines: 1, overflow: TextOverflow.ellipsis),
                        onTap: _profileApiSupported ? () => _open(profile) : null,
                        trailing: PopupMenuButton<String>(
                          tooltip: 'Profile actions',
                          onSelected: (action) {
                            switch (action) {
                              case 'settings': _editSettings(profile); break;
                              case 'clear': _clearData(profile); break;
                              case 'export': _exportConfiguration(profile); break;
                              case 'delete': _deleteProfile(profile); break;
                            }
                          },
                          itemBuilder: (_) => const <PopupMenuEntry<String>>[
                            PopupMenuItem(value: 'settings', child: Text('Settings')),
                            PopupMenuItem(value: 'clear', child: Text('Clear site data')),
                            PopupMenuItem(value: 'export', child: Text('Copy config JSON')),
                            PopupMenuItem(value: 'delete', child: Text('Delete profile')),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _createProfile,
        tooltip: 'New profile',
        child: const Icon(Icons.add),
      ),
    );
  }
}
