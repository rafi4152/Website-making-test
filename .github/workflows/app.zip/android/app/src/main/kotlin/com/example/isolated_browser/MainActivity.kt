package com.example.isolated_browser

import android.os.Handler
import android.os.Looper
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewFeature
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val appChannelName = "isolated_browser/app"
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        flutterEngine.platformViewsController.registry.registerViewFactory(
            "isolated_browser/profile_webview",
            ProfileWebViewFactory(flutterEngine.dartExecutor.binaryMessenger)
        )

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, appChannelName)
            .setMethodCallHandler { call: MethodCall, result: MethodChannel.Result ->
                when (call.method) {
                    "isMultiProfileSupported" -> result.success(
                        WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)
                    )
                    "clearProfileSiteData" -> clearProfileSiteData(call, result)
                    "deleteProfile" -> deleteProfile(call, result)
                    else -> result.notImplemented()
                }
            }
    }

    private fun getProfileId(call: MethodCall): String? {
        val raw = call.argument<String>("profileId") ?: return null
        // Prevent control characters and unreasonable profile identifiers.
        if (raw.length !in 3..100 || !raw.matches(Regex("[A-Za-z0-9_-]+"))) return null
        return raw
    }

    private fun clearProfileSiteData(call: MethodCall, result: MethodChannel.Result) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            result.error("MULTI_PROFILE_UNSUPPORTED", "Android System WebView lacks multi-profile support.", null)
            return
        }
        val profileId = getProfileId(call)
        if (profileId == null) {
            result.error("INVALID_PROFILE", "Invalid profile identifier.", null)
            return
        }
        try {
            val profile = ProfileStore.getInstance().getOrCreateProfile(profileId)
            profile.cookieManager.removeAllCookies { success ->
                mainHandler.post {
                    try {
                        profile.webStorage.deleteAllData()
                        profile.cookieManager.flush()
                        result.success(success)
                    } catch (e: Exception) {
                        result.error("CLEAR_FAILED", e.message ?: "Could not clear site data.", null)
                    }
                }
            }
        } catch (e: Exception) {
            result.error("CLEAR_FAILED", e.message ?: "Could not clear site data.", null)
        }
    }

    private fun deleteProfile(call: MethodCall, result: MethodChannel.Result) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            result.error("MULTI_PROFILE_UNSUPPORTED", "Android System WebView lacks multi-profile support.", null)
            return
        }
        val profileId = getProfileId(call)
        if (profileId == null) {
            result.error("INVALID_PROFILE", "Invalid profile identifier.", null)
            return
        }
        try {
            result.success(ProfileStore.getInstance().deleteProfile(profileId))
        } catch (e: Exception) {
            // The WebView implementation may refuse deletion while profile state
            // is still held in memory. Return a recoverable error, never crash.
            result.error("PROFILE_DELETE_FAILED", e.message ?: "Profile is busy or cannot be deleted.", null)
        }
    }
}
