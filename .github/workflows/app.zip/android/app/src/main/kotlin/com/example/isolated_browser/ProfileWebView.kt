package com.example.isolated_browser

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.platform.PlatformView
import java.io.ByteArrayInputStream

class ProfileWebView(
    context: Context,
    messenger: BinaryMessenger,
    private val viewId: Int,
    private val params: Map<String, Any?>
) : PlatformView {
    private val container = FrameLayout(context)
    private val channel = MethodChannel(messenger, "isolated_browser/webview_$viewId")
    private val profileId: String = params["profileId"] as? String ?: ""
    private val initialUrl: String = params["initialUrl"] as? String ?: "https://duckduckgo.com/"
    private val settings: Map<String, Any?> = (params["settings"] as? Map<String, Any?>) ?: emptyMap()
    private var webView: WebView? = null
    private var progressBar: ProgressBar? = null
    private var destroyed = false

    init {
        channel.setMethodCallHandler(::handleMethodCall)
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            showMessage("Per-profile browsing is unavailable on this Android System WebView. Update Android System WebView/Chrome.")
        } else if (!profileId.matches(Regex("[A-Za-z0-9_-]{3,100}"))) {
            showMessage("Invalid browser profile.")
        } else {
            createProfiledWebView(context)
        }
    }

    private fun showMessage(message: String) {
        val label = TextView(container.context).apply {
            text = message
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(32, 32, 32, 32)
            gravity = android.view.Gravity.CENTER
        }
        container.addView(label, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createProfiledWebView(context: Context) {
        try {
            // Create/resolve the profile, then assign it before the WebView is
            // attached to its parent or begins loading any origin.
            ProfileStore.getInstance().getOrCreateProfile(profileId)
            val view = WebView(context)
            WebViewCompat.setProfile(view, profileId)
            view.setBackgroundColor(Color.WHITE)
            view.setLayerType(View.LAYER_TYPE_HARDWARE, null)

            val webSettings = view.settings
            webSettings.javaScriptEnabled = settings["javaScriptEnabled"] as? Boolean ?: true
            webSettings.loadsImagesAutomatically = settings["loadImages"] as? Boolean ?: true
            webSettings.blockNetworkImage = !(settings["loadImages"] as? Boolean ?: true)
            webSettings.mediaPlaybackRequiresUserGesture = settings["requireMediaGesture"] as? Boolean ?: true
            webSettings.builtInZoomControls = settings["enableZoom"] as? Boolean ?: true
            webSettings.displayZoomControls = false
            webSettings.textZoom = (settings["textZoom"] as? Number)?.toInt()?.coerceIn(50, 200) ?: 100
            webSettings.useWideViewPort = true
            webSettings.loadWithOverviewMode = settings["desktopSite"] as? Boolean ?: false
            webSettings.setSupportMultipleWindows(false)
            webSettings.javaScriptCanOpenWindowsAutomatically = false
            webSettings.allowFileAccess = false
            webSettings.allowContentAccess = false
            webSettings.domStorageEnabled = true
            webSettings.cacheMode = WebSettings.LOAD_DEFAULT
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                webSettings.safeBrowsingEnabled = settings["safeBrowsing"] as? Boolean ?: true
            }
            if (settings["desktopSite"] as? Boolean == true) {
                webSettings.userAgentString = DESKTOP_USER_AGENT
            }
            view.isVerticalScrollBarEnabled = settings["showScrollbars"] as? Boolean ?: true
            view.isHorizontalScrollBarEnabled = settings["showScrollbars"] as? Boolean ?: true
            view.scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY
            view.overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS

            progressBar = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).also { bar ->
                bar.max = 100
                bar.visibility = View.GONE
                val height = (2 * context.resources.displayMetrics.density).toInt().coerceAtLeast(2)
                container.addView(bar, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    height,
                    android.view.Gravity.TOP
                ))
            }

            view.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val scheme = request.url.scheme?.lowercase() ?: return true
                    return scheme != "http" && scheme != "https"
                }

                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                    if ((settings["blockTrackers"] as? Boolean) != true || request.isForMainFrame) return null
                    val host = request.url.host?.lowercase() ?: return null
                    if (TRACKER_HOSTS.any { host == it || host.endsWith(".$it") }) {
                        return WebResourceResponse(
                            "text/plain",
                            "utf-8",
                            ByteArrayInputStream(ByteArray(0))
                        )
                    }
                    return null
                }

                override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                    progressBar?.visibility = View.VISIBLE
                    sendEvent("pageStarted", mapOf("url" to url))
                }

                override fun onPageFinished(view: WebView, url: String) {
                    progressBar?.visibility = View.GONE
                    val script = settings["pageEnhancementScript"] as? String ?: ""
                    if (script.isNotBlank() && (settings["javaScriptEnabled"] as? Boolean != false)) {
                        view.evaluateJavascript(script, null)
                    }
                    sendEvent("pageFinished", mapOf(
                        "url" to url,
                        "title" to (view.title ?: ""),
                        "canGoBack" to view.canGoBack(),
                        "canGoForward" to view.canGoForward()
                    ))
                }

                override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                    if (request.isForMainFrame) {
                        sendEvent("loadError", mapOf("description" to error.description.toString()))
                    }
                }

                override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: android.net.http.SslError) {
                    // Fail closed. Certificate errors must never be silently ignored.
                    handler.cancel()
                }
            }

            view.webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    progressBar?.progress = newProgress
                    if (newProgress >= 100) progressBar?.visibility = View.GONE else progressBar?.visibility = View.VISIBLE
                    if (newProgress == 100 || newProgress % 5 == 0) {
                        sendEvent("progress", mapOf("progress" to newProgress))
                    }
                }
            }

            webView = view
            container.addView(view, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ))
            progressBar?.bringToFront()
            val safeUrl = validatedWebUrl(initialUrl)
            view.loadUrl(safeUrl)
        } catch (e: Exception) {
            showMessage("Could not create isolated profile: ${e.message ?: "unknown WebView error"}")
        }
    }

    private fun validatedWebUrl(raw: String): String {
        var value = raw.trim()
        if (!value.contains("://")) value = "https://$value"
        val uri = runCatching { Uri.parse(value) }.getOrNull()
        return if (uri != null && (uri.scheme == "http" || uri.scheme == "https") && !uri.host.isNullOrBlank()) {
            uri.toString()
        } else {
            "https://duckduckgo.com/"
        }
    }

    private fun handleMethodCall(call: MethodCall, result: MethodChannel.Result) {
        val view = webView
        when (call.method) {
            "loadUrl" -> {
                val raw = call.argument<String>("url")
                if (view == null || raw == null) result.error("WEBVIEW_UNAVAILABLE", "Browser view is not ready.", null)
                else {
                    view.loadUrl(validatedWebUrl(raw))
                    result.success(null)
                }
            }
            "goBack" -> { if (view?.canGoBack() == true) view.goBack(); sendNavState(); result.success(null) }
            "goForward" -> { if (view?.canGoForward() == true) view.goForward(); sendNavState(); result.success(null) }
            "reload" -> { view?.reload(); result.success(null) }
            "canGoBack" -> result.success(view?.canGoBack() == true)
            "getUrl" -> result.success(view?.url)
            "getState" -> result.success(mapOf(
                "url" to view?.url,
                "title" to (view?.title ?: ""),
                "progress" to (progressBar?.progress ?: 0),
                "canGoBack" to (view?.canGoBack() == true),
                "canGoForward" to (view?.canGoForward() == true)
            ))
            "clearSiteData" -> {
                try {
                    val profile = ProfileStore.getInstance().getOrCreateProfile(profileId)
                    profile.cookieManager.removeAllCookies { success ->
                        runCatching { profile.webStorage.deleteAllData() }
                        result.success(success)
                    }
                } catch (e: Exception) {
                    result.error("CLEAR_FAILED", e.message, null)
                }
            }
            else -> result.notImplemented()
        }
    }

    private fun sendNavState() {
        val view = webView ?: return
        sendEvent("navState", mapOf("canGoBack" to view.canGoBack(), "canGoForward" to view.canGoForward()))
    }

    private fun sendEvent(method: String, values: Map<String, Any?>) {
        if (destroyed) return
        container.post {
            if (!destroyed) channel.invokeMethod(method, values)
        }
    }

    override fun getView(): View = container

    override fun dispose() {
        destroyed = true
        channel.setMethodCallHandler(null)
        webView?.let { view ->
            runCatching { view.stopLoading() }
            view.webChromeClient = null
            view.webViewClient = WebViewClient()
            (view.parent as? ViewGroup)?.removeView(view)
            runCatching { view.destroy() }
        }
        webView = null
        progressBar = null
        container.removeAllViews()
        if (settings["clearSiteDataOnClose"] as? Boolean == true &&
            WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            runCatching {
                val store = ProfileStore.getInstance()
                val profile = store.getProfile(profileId) ?: store.getOrCreateProfile(profileId)
                profile.cookieManager.removeAllCookies {
                    runCatching {
                        profile.webStorage.deleteAllData()
                        profile.cookieManager.flush()
                    }
                }
            }
        }
    }

    companion object {
        private const val DESKTOP_USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
        private val TRACKER_HOSTS = setOf(
            "google-analytics.com",
            "googletagmanager.com",
            "connect.facebook.net",
            "doubleclick.net",
            "hotjar.com",
            "segment.io",
            "segment.com",
            "clarity.ms",
            "amplitude.com",
            "mixpanel.com"
        )
    }
}
