import 'package:flutter_test/flutter_test.dart';
import 'package:isolated_browser/profile_model.dart';

void main() {
  test('profile settings survive JSON serialization', () {
    final original = BrowserProfile(
      id: 'p_test_1',
      name: 'Work',
      settings: ProfileSettings(
        javaScriptEnabled: false,
        textZoom: 125,
        customCss: 'body { color: red; }',
      ),
    );
    final restored = BrowserProfile.decode(original.encode());
    expect(restored.name, 'Work');
    expect(restored.settings.javaScriptEnabled, isFalse);
    expect(restored.settings.textZoom, 125);
    expect(restored.settings.customCss, 'body { color: red; }');
  });

  test('configuration import creates a new profile identity', () {
    final original = BrowserProfile(id: 'p_original', name: 'Work');
    final imported = BrowserProfile.importConfiguration(original.exportConfiguration());
    expect(imported.id, isNot('p_original'));
    expect(imported.name, contains('imported'));
  });
}
