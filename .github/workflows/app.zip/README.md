# Isolated Browser (Android / Flutter)

A lightweight Flutter browser starter with AndroidX WebKit multi-profile storage. The profile list and settings are stored locally; each WebView is assigned an AndroidX `Profile` before it is attached or navigates, so cookies and site storage are managed by the native profile rather than by a Dart-side label.

## Important compatibility note

Profile isolation requires the Android System WebView installed on the device to support `WebViewFeature.MULTI_PROFILE`. The app checks this feature and deliberately disables browsing if it is absent. It does not fall back to a shared cookie jar. Test on the exact Android/WebView versions you plan to support.

## Build

Requirements: Flutter stable with Dart SDK >= 3.5, JDK 17, Android SDK Platform 35, and a recent Android System WebView for runtime profile isolation.

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
```

The included GitHub Actions workflow runs those checks and uploads a debug APK. This environment did not have Flutter or the Android SDK installed, so the project has **not** been compiled here; let CI validate it before release.

## Included

- Local unlimited profile metadata (Hive), with unique opaque native profile IDs.
- Native AndroidX WebView profile assignment for cookies/site storage separation.
- Lightweight no-transition Flutter UI.
- Navigation bar, URL validation, back/forward/reload, pop-up blocking.
- Per-profile settings: JavaScript, image loading, media gesture requirement, desktop-site request, zoom, text size, scrollbar visibility, Safe Browsing, local tracker hostname filtering, clear site data on close.
- User-authored custom CSS and JavaScript after navigation completes.
- Profile settings JSON export/import; exports exclude cookies and site data.
- GitHub Actions workflow.

## Deliberate scope limits

This is a compile-oriented starter, **not a claim that every feature in a 50+ item wishlist is complete**. It does not implement proxy/DNS routing, per-profile VPN, Google Drive OAuth backup, cookie import/export, tab grids/multiple windows, or end-to-end encrypted config files. WebView proxy settings are not a normal per-view feature, and treating a setting stub as working proxy isolation would be misleading. The `flutter_inappwebview` dependency is retained as requested, but AndroidX's per-view `setProfile` API is currently reached through a small native platform-view implementation because `flutter_inappwebview` does not expose that hook as an ordinary Dart setting.

Anti-bot prototype masking, browser-fingerprint forgery/noise, certificate-error bypasses, and stealth mechanisms intended to evade site detection are intentionally excluded. SSL certificate errors fail closed. Custom JS is user-authored page customisation and should only be used with scripts you trust.

## Production hardening before release

- Exercise a two-profile isolation test on every supported System WebView version: log into different test accounts, set profile-local localStorage/IndexedDB values, and verify neither is visible in the other profile.
- Add automated Android instrumentation tests that create/destroy profiles repeatedly. AndroidX may reject deleting a profile whose handle has already been loaded in the current process; if that happens, restart the app and delete the profile before opening it in that process.
- Pin Flutter/plugin/Gradle dependencies and review updates before release.
- Add robust tab lifecycle management and an explicit RAM-based tab limit before implementing multiple simultaneous WebViews on budget devices.
- Review privacy notice, data retention, Safe Browsing behavior, and distribution policies.
